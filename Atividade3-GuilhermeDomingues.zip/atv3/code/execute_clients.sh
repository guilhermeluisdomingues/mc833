#!/bin/bash
gcc -Wall -o cliente cliente.c

./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 &
./cliente 127.0.0.1 8000 